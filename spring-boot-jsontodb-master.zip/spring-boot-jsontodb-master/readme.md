## Spring Boot JSON Demo

In this demo we are going to read JSON data from a Spring Boot application
and use that data to populate an H2 database. 


### Spring Boot Introduction Course
Enroll in my Spring Boot Course http://bit.ly/2pQuyFq