package com.mkyong.service;

public interface WeatherService {

    String forecast();

}